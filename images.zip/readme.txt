Project made by:
Nafid Sakkaf
Uday Sharma
Anant Jain
Shahzada Khoso

Print out the files in this archive and place it in front of the camera after starting the application.