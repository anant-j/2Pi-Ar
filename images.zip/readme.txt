Print out the files in this archive and place it in front of the camera after starting the application.

Project made by:
Anant Jain
Nafid Sakkaf
Uday Sharma
Shahzada Khoso
